
function NumberKey(e) //only input number
{
  const charCode = (e.which) ? e.which : keyCode;
  if(charCode > 47 && charCode < 58)
    return true;
  return false; 
}

function CheckNumberphone(id) //check number phone by id
 {
 	let txtid = $("#" + id).val();    
    var regExp = /^(0[235789][0-9]{8}$)/;
     if (!regExp.test(txtid)) 
          alert('Số điện thoại không hợp lệ!');    
 }
function OpenModal()
{
    $('#myModal').appendTo("body");
}
function str_to_curency(a) {
  a.value = a.value.replace(/\./g,""); //Loại bỏ dấu "." phần ngàn nếu có
  a.value = Number(a.value).toLocaleString();
}
function curency_to_number(curency)
{
  return parseFloat(curency.replace(/\./g,""));
}
  
$(document).ready(function(){ //hiển thị ảnh lớn trong trang product
    $('.imgProduct').hover (function (e) {
        const urlimg = $(this).attr('src');
        $('.large-image img').attr('src',urlimg);
        $(".large-image").appendTo('body');
        $('.large-image').toggle();
    });
});


