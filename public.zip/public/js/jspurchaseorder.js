
    function getProductDetails() { //gọi API đổ dữ liệu vao datalist
        var idSupplier = document.getElementById('masp').value;       
        $.ajax({
            type: 'POST',
            url: 'api/product/pddetails',
            data: { masp: idSupplier },
            success: function(response) {
                var spDetails = response.product;
                $("#listproduct").empty(); // Clear previous options
                $.each(spDetails, function(index, spDetail) {
                    $("#listproduct").append('<option value="' + spDetail.masp + '">');
                });                
            },
            error: function(xhr) {
                console.log(xhr);
            }
        });
    }
    
$(document).ready(function(){
        // Use event delegation on the static parent element
        
        makeRequest();
        function makeRequest(){
        $('#TableProduct1').on('blur', '.input_masp', function(){ 
            let masp = $(this).val();
            let indextr = $(this).parents('tr').index();    
            $.ajax({
                type: 'GET',
                url: '/api/product/pdinfo/' + masp,           
                success: function(response){            
                    let product = response.product;               
                    if(response.message_code==200){
                        $.each(product,function(key,value){  
                            $('tr').eq(indextr).attr('dataid',value.id);       
                            $('tr').eq(indextr).find('td').eq(2).text(value.tensp);
                            $('tr').eq(indextr).find('td').eq(3).text(value.chatlieu);
                            $('tr').eq(indextr).find('td').eq(4).text(value.donvi);
                            $('tr').eq(indextr).find('.btnDeleteRow-hide').removeClass('btnDeleteRow-hide');
                            $('tr').eq(indextr).find('ion-icon').addClass('btnDeleteRow-show');
                        });                          
                        addRow();//thêm dòng
                        getIndex();//load lại stt                 
                    }
                },
                error: function(jqXHR, textStatus, errorThrown) {
                    if (jqXHR.status === 429) {
                        console.log('Quá nhiều yêu cầu, đang chờ và thử lại sau.');
                        setTimeout(function () {
                            makeRequest(); // Thử lại yêu cầu
                        }, 5000); 
                    } else {                        
                        console.error('Lỗi không mong muốn:', errorThrown);
                    }
                }
            });
            

        });
        }//test tạo hàm khi gọi api
    
});
 function getInfoProduct(index)
{
    let masp = $(index).val();
    let indextr = $(this).parents('tr').index();
    $.ajax({
        type: 'GET',
        url: '/api/product/pdinfo/' + masp,
        success: function (response) {
            let product = response.product;
            if (response.message_code == 200) {
                $.each(product, function (key, value) {
                    let currentRow = $('tr').eq(indextr);
                    currentRow.attr('dataid', value.id);
                    currentRow.find('td').eq(2).text(value.tensp);
                    currentRow.find('td').eq(3).text(value.chatlieu);
                    currentRow.find('td').eq(4).text(value.donvi);
                    currentRow.find('img').removeClass('btnDeleteRow-hide');
                    currentRow.find('img').addClass('btnDeleteRow-show');
                }); 
                let check = $('tr').eq(indextr).find('td').eq(2).text();
                
                if (check!="") {                                        
                addRow();
                getIndex();               
                }
                              
            }
        },
        error: function(jqXHR, textStatus, errorThrown) {
            if (jqXHR.status === 429) {
                console.log('Quá nhiều yêu cầu, đang chờ và thử lại sau.');                 
            } else {                        
                console.error('Lỗi không mong muốn:', errorThrown);
            }
        }
    });
} 


function getIndex() //Chạy lại cột số thứ tự
{
    let rowCount = $('#TableProduct tr').length;
    for(i=1;i<rowCount;i++)
    {
        $('tr').eq(i).find('td').eq(0).text(i); 
    }    
}
function addRow(callback)
{ 
    let StrTr = "<tr dataid=''><td class='STT_SP'></td><td><input class='input_masp' id='masp' onblur='getInfoProduct(this)' list='listproduct'\
                    placeholder='nhập mã sp' /></td><td class='tensp'></td><td></td><td></td><td><input class='input_soluong' onblur='Thahtien($(this))' value=0 onkeypress='return NumberKey(event)' /></td>\
                    <td><input class='input_dongia' onblur='Thahtien($(this))'oninput='str_to_curency(this);' onkeypress='return NumberKey(event)' value=0 /></td> \
                    <td class='thanhtien'><input id='showthanhtien' value=0 disabled /><a href='#' onclick='RemoveRow($(this))' class='md-altTheme-theme'><img src='/icons/iconBtnDelete.png' class='btnDeleteRow-hide' ></a></td></tr>" ;
    let len = $('#TableProduct tbody tr').length;
    let check = $('tr').eq(len-1).find('td').eq(2).text();
    $('#TableProduct tbody').append(StrTr);
}

function RemoveRow(link) 
{
    let rowindex = $(link).parents('tr').index();
    $('tr').eq(rowindex+1).remove();
    getIndex();
}
function getInfoSupplier(link)
{
    let mancc = $(link).val();
    $.get('api/supplier/' + mancc +'/find',
    function(response){
        let supplier = response.data;    
            $('#idsupplier').val(supplier.id);    
            $('#mancc').val(supplier.mancc);
            $('#sdt').val(supplier.sdtncc);
            $('#diachi').val(supplier.diachincc);
    });
}
//Gửi đơn hàng
$(document).ready(function(){
    $('#btn_dathang').on('click',function(){        
        let mancc = $('#idsupplier').val();
        let ngaydat = $('#ngaydat').val();
        let ngaygiao = $('#ngaygiao').val();
        let staff_id = $('#nguoilap').attr('dataid');
        let listproduct = [];
        let lenTable = $('#TableProduct tr').length;  
        if(mancc=="")
        {
            alert("Vui lòng chọn nhà cung cấp");
        }
        for(let i = 1; i<lenTable-1; i++)
        {
            let idsp = $('tr').eq(i).attr('dataid');
            let soluong = $('tr').eq(i).find('.input_soluong').val();
            if(soluong==0)
            { alert("Vui lòng nhập số lượng ở dòng " + i);
                break;
            }
            listproduct.push([idsp,soluong]);
        } 
        $.post('api/purchaseorder/order', //Gửi danh sách đặt hàng qua API xử lý
        {
            "mancc": mancc,
            "ngaydat": ngaydat,
            "ngaygiao":ngaygiao,
            "staff_id": staff_id,
            "listproduct": listproduct
        },
        function(response){
            alert(response.mancc);
        }) ;
    });
    let today = new Date(); //Set ngày hiện tại cho input ngày
    let formatDay = today.toISOString().split('T')[0];
    $('#ngaydat').val(formatDay);
    $('#ngaygiao').val(formatDay);


});

function Thahtien(index)
{    
     let soluong = $(index).parents('tr').find('.input_soluong').val();
     let dongia = curency_to_number($(index).parents('tr').find('.input_dongia').val());       
     let thanhtien = soluong*dongia;
     $(index).parents('tr').find('#showthanhtien').val(thanhtien.toLocaleString());
}
